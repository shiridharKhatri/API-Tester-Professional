import { Link } from "react-router-dom"
import { Check, X, Star, Zap, Users, Crown, Rocket, ArrowRight, HelpCircle } from "lucide-react"
import "../styles/pricing.css"

const Pricing = () => {
  const plans = [
    {
      name: "Free",
      price: "0",
      period: "forever",
      description: "Perfect for getting started with API testing",
      color: "gray",
      features: [
        { text: "100 API requests per month", included: true },
        { text: "Basic response analysis", included: true },
        { text: "Media detection", included: true },
        { text: "Community support", included: true },
        { text: "Basic themes", included: true },
        { text: "Bulk downloads", included: false },
        { text: "Custom detection keys", included: false },
        { text: "Priority support", included: false },
        { text: "Team collaboration", included: false },
        { text: "Advanced analytics", included: false },
      ],
      cta: "Get Started Free",
      ctaVariant: "secondary",
    },
    {
      name: "Pro",
      price: "19",
      period: "month",
      description: "For professional developers and small teams",
      color: "blue",
      popular: true,
      features: [
        { text: "10,000 API requests per month", included: true },
        { text: "Advanced response analysis", included: true },
        { text: "Smart media detection", included: true },
        { text: "Priority support", included: true },
        { text: "Custom themes", included: true },
        { text: "Bulk downloads", included: true },
        { text: "Custom detection keys", included: true },
        { text: "Request history", included: true },
        { text: "Export capabilities", included: true },
        { text: "Team collaboration", included: false },
      ],
      cta: "Start Pro Trial",
      ctaVariant: "primary",
    },
    {
      name: "Team",
      price: "49",
      period: "month",
      description: "For growing teams and organizations",
      color: "purple",
      features: [
        { text: "50,000 API requests per month", included: true },
        { text: "Advanced response analysis", included: true },
        { text: "AI-powered detection", included: true },
        { text: "Priority support", included: true },
        { text: "Custom themes & branding", included: true },
        { text: "Unlimited bulk downloads", included: true },
        { text: "Advanced detection rules", included: true },
        { text: "Unlimited request history", included: true },
        { text: "Advanced export options", included: true },
        { text: "Team collaboration (5 users)", included: true },
      ],
      cta: "Start Team Trial",
      ctaVariant: "primary",
    },
    {
      name: "Enterprise",
      price: "Custom",
      period: "contact us",
      description: "For large organizations with custom needs",
      color: "green",
      features: [
        { text: "Unlimited API requests", included: true },
        { text: "Enterprise-grade analysis", included: true },
        { text: "Custom AI models", included: true },
        { text: "24/7 dedicated support", included: true },
        { text: "White-label solution", included: true },
        { text: "Enterprise bulk operations", included: true },
        { text: "Custom detection algorithms", included: true },
        { text: "Advanced audit logs", included: true },
        { text: "Custom integrations", included: true },
        { text: "Unlimited team members", included: true },
      ],
      cta: "Contact Sales",
      ctaVariant: "primary",
    },
  ]

  const comparisonFeatures = [
    {
      category: "Core Features",
      features: [
        { name: "API Requests per month", free: "100", pro: "10,000", team: "50,000", enterprise: "Unlimited" },
        { name: "Response Analysis", free: "Basic", pro: "Advanced", team: "Advanced", enterprise: "Enterprise" },
        { name: "Media Detection", free: "✓", pro: "✓", team: "AI-Powered", enterprise: "Custom AI" },
        { name: "Request History", free: "✗", pro: "✓", team: "✓", enterprise: "✓" },
        { name: "Export Capabilities", free: "✗", pro: "✓", team: "Advanced", enterprise: "Custom" },
      ],
    },
    {
      category: "Advanced Features",
      features: [
        { name: "Bulk Downloads", free: "✗", pro: "✓", team: "Unlimited", enterprise: "Enterprise" },
        { name: "Custom Detection Keys", free: "✗", pro: "✓", team: "Advanced", enterprise: "Custom" },
        { name: "Team Collaboration", free: "✗", pro: "✗", team: "5 users", enterprise: "Unlimited" },
        { name: "Custom Themes", free: "Basic", pro: "✓", team: "Branding", enterprise: "White-label" },
        { name: "API Access", free: "✗", pro: "✗", team: "✓", enterprise: "✓" },
      ],
    },
    {
      category: "Support & Security",
      features: [
        { name: "Support Level", free: "Community", pro: "Priority", team: "Priority", enterprise: "24/7 Dedicated" },
        { name: "SLA Guarantee", free: "✗", pro: "99.5%", team: "99.9%", enterprise: "99.99%" },
        { name: "Security Features", free: "Standard", pro: "Enhanced", team: "Advanced", enterprise: "Enterprise" },
        { name: "Audit Logs", free: "✗", pro: "✗", team: "Basic", enterprise: "Advanced" },
        { name: "SSO Integration", free: "✗", pro: "✗", team: "✗", enterprise: "✓" },
      ],
    },
  ]

  const faqs = [
    {
      question: "Can I change plans anytime?",
      answer:
        "Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately for upgrades, and at the next billing cycle for downgrades.",
    },
    {
      question: "What happens if I exceed my request limit?",
      answer:
        "We'll notify you when you're approaching your limit. You can upgrade your plan for immediate access to more requests, or wait for your limit to reset.",
    },
    {
      question: "Do you offer refunds?",
      answer:
        "Yes, we offer a 30-day money-back guarantee for all paid plans. If you're not satisfied, contact our support team for a full refund.",
    },
    {
      question: "Is there a free trial for paid plans?",
      answer: "Yes, all paid plans come with a 14-day free trial. No credit card required to start your trial.",
    },
    {
      question: "Can I use Apix for commercial projects?",
      answer:
        "All our plans, including the free plan, can be used for commercial projects. Enterprise plans offer additional commercial licensing options.",
    },
    {
      question: "What payment methods do you accept?",
      answer:
        "We accept all major credit cards, PayPal, and for Enterprise plans, we also support bank transfers and custom billing arrangements.",
    },
  ]

  return (
    <div className="pricing-page">
      {/* Hero Section */}
      <section className="pricing-hero">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">
              Simple, <span className="gradient-text">Transparent</span> Pricing
            </h1>
            <p className="hero-description">
              Choose the perfect plan for your API testing needs. Start free and scale as you grow.
            </p>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="pricing-section">
        <div className="container">
          <div className="pricing-grid">
            {plans.map((plan, index) => (
              <div key={index} className={`pricing-card ${plan.color} ${plan.popular ? "popular" : ""}`}>
                {plan.popular && (
                  <div className="popular-badge">
                    <Star size={16} />
                    Most Popular
                  </div>
                )}
                <div className="plan-header">
                  <h3 className="plan-name">{plan.name}</h3>
                  <div className="plan-price">
                    <span className="price">{plan.price === "Custom" ? plan.price : `$${plan.price}`}</span>
                    {plan.price !== "Custom" && <span className="period">/{plan.period}</span>}
                  </div>
                  <p className="plan-description">{plan.description}</p>
                </div>
                <div className="plan-features">
                  <h4 className="features-title">What's included:</h4>
                  <ul className="features-list">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className={`feature-item ${!feature.included ? "limitation" : ""}`}>
                        <div className={`feature-icon ${feature.included ? "check" : "cross"}`}>
                          {feature.included ? <Check size={16} /> : <X size={16} />}
                        </div>
                        <span>{feature.text}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="plan-cta">
                  <Link
                    to={plan.name === "Enterprise" ? "/contact" : "/signup"}
                    className={`btn ${plan.ctaVariant === "primary" ? "btn-primary" : "btn-secondary"} btn-large btn-full`}
                  >
                    {plan.name === "Free" && <Zap size={20} />}
                    {plan.name === "Pro" && <Rocket size={20} />}
                    {plan.name === "Team" && <Users size={20} />}
                    {plan.name === "Enterprise" && <Crown size={20} />}
                    {plan.cta}
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Comparison */}
      <section className="features-comparison">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Compare Plans</h2>
            <p className="section-description">Detailed comparison of features across all plans</p>
          </div>
          <div className="comparison-table">
            <div className="table-header">
              <div className="feature-column">Features</div>
              <div className="plan-column">Free</div>
              <div className="plan-column">Pro</div>
              <div className="plan-column">Team</div>
              <div className="plan-column">Enterprise</div>
            </div>
            <div className="table-body">
              {comparisonFeatures.map((category, categoryIndex) => (
                <div key={categoryIndex}>
                  {category.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="table-row">
                      <div className="feature-name">{feature.name}</div>
                      <div className="feature-value">
                        {feature.free === "✓" ? (
                          <Check className="check" size={16} />
                        ) : feature.free === "✗" ? (
                          <X className="cross" size={16} />
                        ) : (
                          feature.free
                        )}
                      </div>
                      <div className="feature-value">
                        {feature.pro === "✓" ? (
                          <Check className="check" size={16} />
                        ) : feature.pro === "✗" ? (
                          <X className="cross" size={16} />
                        ) : (
                          feature.pro
                        )}
                      </div>
                      <div className="feature-value">
                        {feature.team === "✓" ? (
                          <Check className="check" size={16} />
                        ) : feature.team === "✗" ? (
                          <X className="cross" size={16} />
                        ) : (
                          feature.team
                        )}
                      </div>
                      <div className="feature-value">
                        {feature.enterprise === "✓" ? (
                          <Check className="check" size={16} />
                        ) : feature.enterprise === "✗" ? (
                          <X className="cross" size={16} />
                        ) : (
                          feature.enterprise
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="faq-section">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">Frequently Asked Questions</h2>
            <p className="section-description">Everything you need to know about our pricing</p>
          </div>
          <div className="faq-grid">
            {faqs.map((faq, index) => (
              <div key={index} className="faq-item">
                <h3 className="faq-question">
                  <HelpCircle size={20} />
                  {faq.question}
                </h3>
                <p className="faq-answer">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="pricing-cta">
        <div className="container">
          <div className="cta-content">
            <h2 className="cta-title">Ready to Get Started?</h2>
            <p className="cta-description">
              Join thousands of developers who trust Apix for their API testing needs. Start your free trial today.
            </p>
            <div className="cta-actions">
              <Link to="/signup" className="btn btn-primary btn-large">
                <Rocket size={20} />
                Start Free Trial
                <ArrowRight size={16} />
              </Link>
              <Link to="/contact" className="btn btn-secondary btn-large">
                Contact Sales
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Pricing
