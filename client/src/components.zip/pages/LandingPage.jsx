"use client"

import { Link } from "react-router-dom"
import { motion, useScroll, useTransform } from "framer-motion"
import { useRef } from "react"
import {
  Rocket,
  Zap,
  Shield,
  Globe,
  Code,
  Download,
  Play,
  CheckCircle,
  ArrowRight,
  Star,
  Users,
  Clock,
  Target,
  Sparkles,
  Send,
  BarChart3,
  Brain,
  Database,
  Smartphone,
  Monitor,
  Activity,
  Layers,
  Cpu,
  Lock,
} from "lucide-react"
import "../styles/landing.css"

const LandingPage = () => {
  const { scrollYProgress } = useScroll()
  const heroRef = useRef(null)

  const y = useTransform(scrollYProgress, [0, 1], [0, -100])
  const opacity = useTransform(scrollYProgress, [0, 0.3], [1, 0])

  const features = [
    {
      icon: <Zap />,
      title: "Lightning Fast",
      description: "Execute API requests in milliseconds with our optimized engine and real-time response analysis.",
      color: "from-amber-400 via-orange-500 to-red-500",
      iconColor: "text-orange-500",
      delay: 0.1,
    },
    {
      icon: <Brain />,
      title: "AI-Powered Detection",
      description: "Smart media detection that automatically extracts and organizes content from API responses.",
      color: "from-purple-400 via-pink-500 to-rose-500",
      iconColor: "text-purple-500",
      delay: 0.2,
    },
    {
      icon: <Shield />,
      title: "Enterprise Security",
      description: "Bank-grade security with encrypted requests and industry-standard data protection.",
      color: "from-emerald-400 via-teal-500 to-cyan-500",
      iconColor: "text-emerald-500",
      delay: 0.3,
    },
    {
      icon: <Code />,
      title: "Advanced Analysis",
      description: "Deep response analysis with syntax highlighting and intelligent data structure visualization.",
      color: "from-blue-400 via-indigo-500 to-purple-500",
      iconColor: "text-blue-500",
      delay: 0.4,
    },
    {
      icon: <Download />,
      title: "Bulk Operations",
      description: "Download all detected media as organized archives and export in multiple formats.",
      color: "from-violet-400 via-purple-500 to-indigo-500",
      iconColor: "text-violet-500",
      delay: 0.5,
    },
    {
      icon: <BarChart3 />,
      title: "Performance Insights",
      description: "Comprehensive metrics, response time analysis, and debugging tools for optimization.",
      color: "from-pink-400 via-rose-500 to-red-500",
      iconColor: "text-pink-500",
      delay: 0.6,
    },
  ]

  const stats = [
    {
      icon: <Users />,
      value: "50K+",
      label: "Active Developers",
      color: "from-blue-500 to-cyan-500",
      iconColor: "text-blue-500",
    },
    {
      icon: <Clock />,
      value: "1M+",
      label: "API Tests Run",
      color: "from-emerald-500 to-teal-500",
      iconColor: "text-emerald-500",
    },
    {
      icon: <Target />,
      value: "99.9%",
      label: "Uptime SLA",
      color: "from-purple-500 to-violet-500",
      iconColor: "text-purple-500",
    },
    {
      icon: <Star />,
      value: "4.9/5",
      label: "User Rating",
      color: "from-amber-500 to-orange-500",
      iconColor: "text-amber-500",
    },
  ]

  const platforms = [
    {
      icon: <Monitor />,
      title: "Web Application",
      description: "Full-featured browser-based testing suite with advanced capabilities",
      color: "from-blue-500 to-indigo-600",
      iconColor: "text-blue-500",
    },
    {
      icon: <Smartphone />,
      title: "Mobile Optimized",
      description: "Responsive design for seamless testing on any device, anywhere",
      color: "from-emerald-500 to-teal-600",
      iconColor: "text-emerald-500",
    },
    {
      icon: <Database />,
      title: "API Integration",
      description: "Programmatic access via comprehensive REST API with full documentation",
      color: "from-purple-500 to-violet-600",
      iconColor: "text-purple-500",
    },
  ]

  const floatingElements = [
    { icon: <Cpu />, delay: 0, duration: 6 },
    { icon: <Lock />, delay: 1, duration: 8 },
    { icon: <Activity />, delay: 2, duration: 7 },
    { icon: <Layers />, delay: 3, duration: 9 },
  ]

  return (
    <div className="landing-page">
      {/* Floating Background Elements */}
      <div className="floating-bg">
        {floatingElements.map((element, index) => (
          <motion.div
            key={index}
            className={`floating-element floating-element-${index + 1}`}
            animate={{
              y: [-20, 20, -20],
              x: [-10, 10, -10],
              rotate: [0, 360],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: element.duration,
              repeat: Number.POSITIVE_INFINITY,
              delay: element.delay,
              ease: "easeInOut",
            }}
          >
            {element.icon}
          </motion.div>
        ))}
      </div>

      {/* Hero Section */}
      <motion.section ref={heroRef} className="hero" style={{ y, opacity }}>
        <div className="hero-bg">
          <div className="hero-gradient"></div>
          <div className="hero-mesh"></div>
        </div>

        <div className="container">
          <div className="hero-content">
            <motion.div
              className="hero-badge"
              initial={{ opacity: 0, y: 30, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              whileHover={{ scale: 1.05 }}
            >
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
              >
                <Sparkles className="w-4 h-4 text-violet-500" />
              </motion.div>
              <span>The Future of API Testing</span>
              <motion.div
                className="badge-glow"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
              />
            </motion.div>

            <motion.h1
              className="hero-title"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.3, ease: "easeOut" }}
            >
              <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5, duration: 0.8 }}>
                Professional API Testing
              </motion.span>
              <br />
              <motion.span
                className="hero-gradient-text"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8, duration: 0.8 }}
              >
                Made Extraordinary
              </motion.span>
            </motion.h1>

            <motion.p
              className="hero-description"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              The most advanced API testing platform with intelligent media detection, real-time analysis, and
              enterprise-grade security. Built for developers who demand excellence.
            </motion.p>

            <motion.div
              className="hero-actions"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              <motion.div whileHover={{ scale: 1.05, y: -2 }} whileTap={{ scale: 0.98 }}>
                <Link to="/tester" className="btn-primary">
                  <motion.div animate={{ x: [0, 3, 0] }} transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}>
                    <Rocket className="w-5 h-5" />
                  </motion.div>
                  Start Testing Free
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </motion.div>

              <motion.div whileHover={{ scale: 1.05, y: -2 }} whileTap={{ scale: 0.98 }}>
                <Link to="/about" className="btn-secondary">
                  <Play className="w-5 h-5 text-emerald-500" />
                  Watch Demo
                </Link>
              </motion.div>
            </motion.div>

            <motion.div
              className="hero-stats"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 1 }}
            >
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  className="stat-card"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.2 + index * 0.1, duration: 0.6 }}
                  whileHover={{
                    y: -5,
                    scale: 1.02,
                    transition: { type: "spring", stiffness: 300 },
                  }}
                >
                  <motion.div
                    className={`stat-icon bg-gradient-to-r ${stat.color}`}
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <motion.div
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, delay: index * 0.2 }}
                    >
                      {stat.icon}
                    </motion.div>
                  </motion.div>
                  <div className="stat-content">
                    <motion.div
                      className="stat-value"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 1.5 + index * 0.1, type: "spring", stiffness: 200 }}
                    >
                      {stat.value}
                    </motion.div>
                    <div className="stat-label">{stat.label}</div>
                  </div>
                  <motion.div
                    className="stat-glow"
                    animate={{ opacity: [0, 0.5, 0] }}
                    transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, delay: index * 0.5 }}
                  />
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Demo Section */}
      <section className="demo-section">
        <div className="container">
          <motion.div
            className="section-header-modern"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <motion.div className="section-badge" whileHover={{ scale: 1.05 }}>
              <Activity className="w-4 h-4 text-emerald-500" />
              Live Demo
            </motion.div>
            <h2 className="section-title-modern">
              See <span className="gradient-text">Apix in Action</span>
            </h2>
            <p className="section-description-modern">
              Experience the power of intelligent API testing with real-time media detection and advanced analysis
            </p>
          </motion.div>

          <div className="demo-container">
            <motion.div
              className="demo-card"
              initial={{ opacity: 0, x: -100, rotateY: -15 }}
              whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              whileHover={{
                y: -10,
                rotateY: 5,
                transition: { type: "spring", stiffness: 300 },
              }}
            >
              <div className="demo-header">
                <div className="demo-title">
                  <motion.div
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                  >
                    <Send className="w-5 h-5 text-blue-500" />
                  </motion.div>
                  API Request
                </div>
                <motion.div className="method-badge get" whileHover={{ scale: 1.1 }}>
                  GET
                </motion.div>
              </div>
              <div className="demo-content">
                <motion.div
                  className="demo-url"
                  initial={{ width: 0 }}
                  whileInView={{ width: "100%" }}
                  transition={{ duration: 1, delay: 0.5 }}
                >
                  <code>https://api.unsplash.com/photos/featured</code>
                </motion.div>
                <div className="demo-headers">
                  {[
                    { key: "Authorization:", value: "Bearer your-api-key" },
                    { key: "Content-Type:", value: "application/json" },
                  ].map((header, index) => (
                    <motion.div
                      key={index}
                      className="header-item"
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.7 + index * 0.2 }}
                      viewport={{ once: true }}
                    >
                      <span className="header-key">{header.key}</span>
                      <span className="header-value">{header.value}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>

            <motion.div
              className="demo-arrow"
              animate={{
                x: [0, 10, 0],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 2,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
              }}
            >
              <ArrowRight className="w-8 h-8 text-violet-500" />
            </motion.div>

            <motion.div
              className="demo-card"
              initial={{ opacity: 0, x: 100, rotateY: 15 }}
              whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
              whileHover={{
                y: -10,
                rotateY: -5,
                transition: { type: "spring", stiffness: 300 },
              }}
            >
              <div className="demo-header">
                <div className="demo-title">
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                  >
                    <CheckCircle className="w-5 h-5 text-emerald-500" />
                  </motion.div>
                  Smart Analysis
                </div>
                <motion.div
                  className="status-badge success"
                  animate={{
                    boxShadow: ["0 0 0 0 rgba(16, 185, 129, 0.7)", "0 0 0 10px rgba(16, 185, 129, 0)"],
                  }}
                  transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                >
                  200 OK
                </motion.div>
              </div>
              <div className="demo-content">
                <motion.div
                  className="demo-response"
                  initial={{ height: 0, opacity: 0 }}
                  whileInView={{ height: "auto", opacity: 1 }}
                  transition={{ duration: 0.8, delay: 0.6 }}
                  viewport={{ once: true }}
                >
                  {[
                    { key: '"id":', value: '"abc123"', type: "string" },
                    { key: '"urls":', value: "{ ... }", type: "object" },
                    { key: '"description":', value: '"Beautiful sunset"', type: "string" },
                  ].map((line, index) => (
                    <motion.div
                      key={index}
                      className="response-line"
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.8 + index * 0.2 }}
                      viewport={{ once: true }}
                    >
                      <span className="response-key">{line.key}</span>
                      <span className={`response-${line.type}`}>{line.value}</span>
                    </motion.div>
                  ))}
                </motion.div>
                <motion.div
                  className="detection-results"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.2 }}
                  viewport={{ once: true }}
                >
                  {[
                    { icon: <Download className="w-4 h-4" />, text: "3 Images Detected", color: "text-emerald-500" },
                    { icon: <Globe className="w-4 h-4" />, text: "2 Links Found", color: "text-blue-500" },
                  ].map((item, index) => (
                    <motion.div
                      key={index}
                      className="detection-item"
                      whileHover={{ scale: 1.05, y: -2 }}
                      animate={{
                        y: [0, -3, 0],
                      }}
                      transition={{
                        duration: 3,
                        repeat: Number.POSITIVE_INFINITY,
                        delay: index * 0.5,
                      }}
                    >
                      <motion.div
                        className={`detection-icon ${item.color}`}
                        animate={{ rotate: [0, 360] }}
                        transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, delay: index * 0.5 }}
                      >
                        {item.icon}
                      </motion.div>
                      <span>{item.text}</span>
                    </motion.div>
                  ))}
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="container">
          <motion.div
            className="section-header-modern"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <motion.div className="section-badge" whileHover={{ scale: 1.05 }}>
              <Zap className="w-4 h-4 text-amber-500" />
              Features
            </motion.div>
            <h2 className="section-title-modern">
              <span className="gradient-text">Powerful Features</span> for Modern APIs
            </h2>
            <p className="section-description-modern">
              Everything you need to test, analyze, and debug APIs with unprecedented efficiency and precision
            </p>
          </motion.div>

          <div className="features-grid">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="feature-card"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: feature.delay }}
                viewport={{ once: true }}
                whileHover={{
                  y: -10,
                  scale: 1.02,
                  transition: { type: "spring", stiffness: 300 },
                }}
              >
                <motion.div
                  className={`feature-icon bg-gradient-to-r ${feature.color}`}
                  whileHover={{
                    rotate: 360,
                    scale: 1.1,
                  }}
                  transition={{ duration: 0.6 }}
                >
                  <motion.div
                    animate={{
                      rotateY: [0, 180, 360],
                      scale: [1, 1.1, 1],
                    }}
                    transition={{
                      duration: 4,
                      repeat: Number.POSITIVE_INFINITY,
                      delay: feature.delay * 2,
                    }}
                  >
                    {feature.icon}
                  </motion.div>
                </motion.div>
                <h3 className="feature-title">{feature.title}</h3>
                <p className="feature-description">{feature.description}</p>
                <motion.div
                  className="feature-glow"
                  animate={{ opacity: [0, 0.3, 0] }}
                  transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, delay: feature.delay }}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Platforms Section */}
      <section className="platforms-section">
        <div className="container">
          <motion.div
            className="section-header-modern"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <motion.div className="section-badge" whileHover={{ scale: 1.05 }}>
              <Globe className="w-4 h-4 text-blue-500" />
              Platforms
            </motion.div>
            <h2 className="section-title-modern">
              Available <span className="gradient-text">Everywhere</span>
            </h2>
            <p className="section-description-modern">
              Access Apix on any device, anywhere, anytime with our responsive design and cross-platform compatibility
            </p>
          </motion.div>

          <div className="platforms-grid">
            {platforms.map((platform, index) => (
              <motion.div
                key={index}
                className="platform-card"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                whileHover={{
                  y: -8,
                  scale: 1.02,
                  transition: { type: "spring", stiffness: 300 },
                }}
              >
                <motion.div
                  className={`platform-icon bg-gradient-to-r ${platform.color}`}
                  whileHover={{
                    rotate: 360,
                    scale: 1.1,
                  }}
                  transition={{ duration: 0.6 }}
                >
                  <motion.div
                    animate={{
                      y: [0, -5, 0],
                      rotateY: [0, 180, 360],
                    }}
                    transition={{
                      duration: 6,
                      repeat: Number.POSITIVE_INFINITY,
                      delay: index * 0.5,
                    }}
                  >
                    {platform.icon}
                  </motion.div>
                </motion.div>
                <h3 className="platform-title">{platform.title}</h3>
                <p className="platform-description">{platform.description}</p>
                <motion.div
                  className="platform-glow"
                  animate={{ opacity: [0, 0.2, 0] }}
                  transition={{ duration: 5, repeat: Number.POSITIVE_INFINITY, delay: index * 0.8 }}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="cta-bg">
          <motion.div
            className="cta-gradient"
            animate={{
              background: [
                "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
                "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
                "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
              ],
            }}
            transition={{ duration: 10, repeat: Number.POSITIVE_INFINITY }}
          />
        </div>

        <div className="container">
          <div className="cta-content">
            <motion.div
              className="cta-icon"
              initial={{ opacity: 0, scale: 0.5 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              whileHover={{
                scale: 1.1,
                rotate: 360,
                transition: { duration: 0.6 },
              }}
            >
              <motion.div
                animate={{
                  rotate: [0, 360],
                  scale: [1, 1.1, 1],
                }}
                transition={{ duration: 8, repeat: Number.POSITIVE_INFINITY }}
              >
                <Rocket className="w-12 h-12" />
              </motion.div>
            </motion.div>

            <motion.h2
              className="cta-title"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Ready to Transform Your API Testing?
            </motion.h2>

            <motion.p
              className="cta-description"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
            >
              Join thousands of developers who trust Apix for their API testing needs. Start your free trial today and
              experience the difference.
            </motion.p>

            <motion.div
              className="cta-actions"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              viewport={{ once: true }}
            >
              <motion.div whileHover={{ scale: 1.05, y: -3 }} whileTap={{ scale: 0.98 }}>
                <Link to="/tester" className="btn-cta-primary">
                  <Rocket className="w-5 h-5" />
                  Start Testing Free
                  <motion.div animate={{ x: [0, 3, 0] }} transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}>
                    <ArrowRight className="w-4 h-4" />
                  </motion.div>
                </Link>
              </motion.div>

              <motion.div whileHover={{ scale: 1.05, y: -3 }} whileTap={{ scale: 0.98 }}>
                <Link to="/pricing" className="btn-cta-secondary">
                  View Pricing
                </Link>
              </motion.div>
            </motion.div>

            <motion.div
              className="cta-features"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              viewport={{ once: true }}
            >
              {["No credit card required", "Free forever plan", "Cancel anytime"].map((feature, index) => (
                <motion.div
                  key={index}
                  className="cta-feature"
                  whileHover={{ scale: 1.05 }}
                  animate={{ y: [0, -2, 0] }}
                  transition={{
                    duration: 3,
                    repeat: Number.POSITIVE_INFINITY,
                    delay: index * 0.3,
                  }}
                >
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{
                      duration: 2,
                      repeat: Number.POSITIVE_INFINITY,
                      delay: index * 0.3,
                    }}
                  >
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                  </motion.div>
                  <span>{feature}</span>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default LandingPage
